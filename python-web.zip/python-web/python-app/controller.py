def application(environ, start_response):
    start_response('200 OK', [('Content-Type', 'text/html')])
    path = environ['PATH_INFO'][1:]

    if path == 'Adeu':
        return Adeu(environ,start_response)
    elif path == 'Hola':
        return Hola(environ,start_response)

    output = b'<h1>Benvinguts a Python</h1>'

    return [output]

def Adeu(environ,start_response):
    output = b'<h1>Adeu Python</h1>'

    return [output]


def Hola(environ,start_response):
    output = b'<h1>Hola Python</h1>'

    return [output]






